from flask import Flask, render_template, request, jsonify
import pandas as pd
from web3 import Web3
app = Flask(__name__)

data = pd.read_csv("final_products.csv")
data['Contains'] = data['Contains'].str.lower()
w3 = Web3(Web3.HTTPProvider('http://127.0.0.1:7545'))  # Connect to a local Ethereum node (e.g., Ganache)
contract_address = 'YOUR_CONTRACT_ADDRESS'
contract_abi = 'YOUR_CONTRACT_ABI'
contract = w3.eth.contract(address=contract_address, abi=contract_abi)

def rule_based_classifier(data, user_preferences):
    results = data.copy()

    # Convert the necessary values to integers
    user_preferences['vitamin_a'] = int(user_preferences['vitamin_a'])
    user_preferences['vitamin_c'] = int(user_preferences['vitamin_c'])

    results = results[(results['VitaminA'] == user_preferences['vitamin_a']) & (results['VitaminC'] == user_preferences['vitamin_c'])]
    # print("After VitaminA and VitaminC filter:", len(results))

    for key, value_range in user_preferences['ranges'].items():
        # Convert the range values to integers
        value_range = (int(value_range[0]), int(value_range[1]))
        results = results[(results[key] >= value_range[0]) & (results[key] <= value_range[1])]
    # print("After ranges filter:", len(results))

    if user_preferences['exclude_ingredients']:
        for ingredient in user_preferences['exclude_ingredients']:
            results = results[~results['Contains'].str.contains(ingredient)]
    # print("After exclude_ingredients filter:", len(results))

    results = results[(results['Safe'].str.contains(user_preferences['health_condition'])) | (~results['Not_recommended'].str.contains(user_preferences['health_condition']))]
    # print("After health_condition filter:", len(results))

    return results


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/recommendations', methods=['POST'])
def get_recommendations():
    user_preferences = request.get_json()
    user_preferences['vitamin_a'] = int(user_preferences['vitamin_a'])  # Add this line
    user_preferences['vitamin_c'] = int(user_preferences['vitamin_c'])  # Add this line
    print("Received user preferences:", user_preferences)
    # print("data=",data)
    recommended_products = rule_based_classifier(data, user_preferences)
    recommended_products = recommended_products[:10]
    response = jsonify(recommended_products.to_dict(orient='records'))
    response.status_code = 200

    print("Response:", response)
    return response
@app.route('/update-stock', methods=['POST'])
def update_stock():
    stock_update = request.get_json()
    product_id = int(stock_update['product_id'])
    quantity = int(stock_update['quantity'])

    # Call the smart contract's shop function to update stock on the blockchain
    place_order(product_id, quantity)

    return jsonify({'status': 'success'})


def place_order(product_id, quantity):
    # You will need to replace the following values with your own
    # The account address that will be used to send the transaction
    sender_address = 'YOUR_SENDER_ADDRESS'
    # The private key of the sender account
    sender_private_key = 'YOUR_SENDER_PRIVATE_KEY'

    # The nonce for the sender account
    nonce = w3.eth.getTransactionCount(sender_address)

    # The transaction object to call the shop function in the smart contract
    txn = contract.functions.shop(product_id, quantity).buildTransaction({
        'from': sender_address,
        'gas': 2000000,
        'gasPrice': w3.eth.gasPrice,
        'nonce': nonce,
    })

    # Sign the transaction
    signed_txn = w3.eth.account.signTransaction(txn, sender_private_key)

    # Send the transaction
    txn_hash = w3.eth.sendRawTransaction(signed_txn.rawTransaction)

    # Wait for the transaction to be mined
    txn_receipt = w3.eth.waitForTransactionReceipt(txn_hash)

    return txn_receipt
if __name__ == '__main__':
    app.run(debug=True)
