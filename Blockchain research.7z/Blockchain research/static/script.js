function createTableHeader() {
    const headers = [
        'No.',
        'Product_ID',
        'Name',
        'Rating',
        'N_reviews',
        'Calcium_mg',
        'Calories',
        'Carbohydrate',
        'Cholesterol',
        'Contains',
        'Fat',
        'Iron_mg',
        'Not_recommended',
        'Protein',
        'Safe',
        'Sodium',
        'Sugar_g',
        'VitaminA',
        'VitaminC'
    ];

    const headerRow = document.createElement('tr');
    headers.forEach(headerText => {
        const header = document.createElement('th');
        header.textContent = headerText;
        headerRow.appendChild(header);
    });

    return headerRow;
}

document.getElementById('preferences-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const healthCondition = document.getElementById('health_condition').value;
    const vitaminA = document.getElementById('vitamin_a').value;
    const vitaminC = document.getElementById('vitamin_c').value;
    const excludeIngredients = document.getElementById('exclude_ingredients').value.split(',');

    const ranges = {
        'Fat': [
            parseFloat(document.getElementById('fat_min').value),
            parseFloat(document.getElementById('fat_max').value)
        ],
        'Cholesterol': [
            parseFloat(document.getElementById('cholesterol_min').value),
            parseFloat(document.getElementById('cholesterol_max').value)
        ],
        'Sodium': [
            parseFloat(document.getElementById('sodium_min').value),
            parseFloat(document.getElementById('sodium_max').value)
        ],
        'Carbohydrate': [
            parseFloat(document.getElementById('carbohydrate_min').value),
            parseFloat(document.getElementById('carbohydrate_max').value)
        ],
        'Protein': [
            parseFloat(document.getElementById('protein_min').value),
            parseFloat(document.getElementById('protein_max').value)
        ],
        'Calcium_mg': [
            parseFloat(document.getElementById('calcium_min').value),
            parseFloat(document.getElementById('calcium_max').value)
        ],
        'Sugar_g': [
            parseFloat(document.getElementById('sugar_min').value),
            parseFloat(document.getElementById('sugar_max').value)
        ],
        'Iron_mg': [
            parseFloat(document.getElementById('iron_min').value),
            parseFloat(document.getElementById('iron_max').value)
        ],
       
        'Calories': [
            parseFloat(document.getElementById('calories_min').value),
            parseFloat(document.getElementById('calories_max').value)
            ],
            };
            const userPreferences = {
                health_condition: healthCondition,
                vitamin_a: parseInt(vitaminA),
                vitamin_c: parseInt(vitaminC),
                exclude_ingredients: excludeIngredients.map(ingredient => ingredient.trim().toLowerCase()),
                ranges: ranges
            };
            
            const response = await fetch('/recommendations', {
                method: 'POST',
                body: JSON.stringify({
                    health_condition: healthCondition,
                    vitamin_a: vitaminA,
                    vitamin_c: vitaminC,
                    exclude_ingredients: excludeIngredients.map(ingredient => ingredient.trim().toLowerCase()),
                    ranges: ranges
                }),
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            if (response.ok) {
                const recommendedProducts = await response.json();
                console.log('Received recommendations:', recommendedProducts);
                console.log(JSON.stringify(recommendedProducts, null, 2));
                const productList = document.getElementById('product-list');
                productList.innerHTML = '';
            
                // Add table header
                productList.appendChild(createTableHeader());
            
                recommendedProducts.forEach((product, index) => {
                    const tableRow = document.createElement('tr');
                
                    const rowNumCell = document.createElement('td');
                    rowNumCell.textContent = index + 1;
                    tableRow.appendChild(rowNumCell);
                
                    const keys = [
                        'Product_ID',
                        'Name',
                        'Rating',
                        'N_reviews',
                        'Calcium_mg',
                        'Calories',
                        'Carbohydrate',
                        'Cholesterol',
                        'Contains',
                        'Fat',
                        'Iron_mg',
                        'Not_recommended',
                        'Protein',
                        'Safe',
                        'Sodium',
                        'Sugar_g',
                        'VitaminA',
                        'VitaminC'
                    ];
                
                    keys.forEach(key => {
                        const cell = document.createElement('td');
                        cell.textContent = product[key];
                        tableRow.appendChild(cell);
                    });
                
                    productList.appendChild(tableRow);
                });                
            } else {
                console.error('Error getting recommendations:', response.statusText);
            }
            
            });