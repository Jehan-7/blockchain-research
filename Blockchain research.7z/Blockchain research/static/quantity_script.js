async function updateStock(productId, quantity) {
    const response = await fetch('/update-stock', {
      method: 'POST',
      body: JSON.stringify({ product_id: productId, quantity: parseInt(quantity) }),
      headers: {
        'Content-Type': 'application/json',
      },
    });
  
    if (response.ok) {
      console.log('Stock updated successfully');
    } else {
      console.error('Error updating stock:', response.statusText);
    }
  }
  
  document.getElementById('quantity-form').addEventListener('submit', async (e) => {
    e.preventDefault();
  
    const productId = document.getElementById('product_id').value;
    const quantity = document.getElementById('quantity').value;
  
    // Show a confirmation alert
    const confirmed = confirm(`Product ID: ${productId}\nQuantity: ${quantity}\n\nAre you sure you want to submit?`);
  
    // If the user confirms, update the stock levels
    if (confirmed) {
      await updateStock(productId, quantity);
    }
  });
  